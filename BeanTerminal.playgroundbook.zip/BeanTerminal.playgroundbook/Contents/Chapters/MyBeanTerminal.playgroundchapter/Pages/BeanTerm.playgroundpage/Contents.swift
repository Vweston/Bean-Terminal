// My Bean+ Terminal iPad playground 
// version 0.6

// because I use a large uiview, the Liveview must be fullscreen in   
// portrait mode to see entire view.

// Has all sourcecode in Contents.swift
// when code is to version 1, i wll break it up

// Important Playground Notes
// To connect to a specific bean you must set the BLEname to your actual beans name

// Everything is in this one file. I would like to properly separate classes out into their
// respective files & roles using delegates or notifications, but I still haven't 
// figured how that all works.
// I still have my debugging code included but commented out. Need to remove it.

import Foundation
import CoreBluetooth
import UIKit
import PlaygroundSupport

// public variables 
public var beanTemp = 0
public var serialmsgs = ""
public var BLEname = "Bean+"
public var beanBattLevel = 0
public var beanArduinoPower = false

// Globals
var nGTMsgNum = 0
var sGTMsgNum = 0
var currentGTMsgNum = 5
var bean: CBPeripheral?
var beanSerialCharacteristic: CBCharacteristic?
//var nMsgLength = 0
//var nMsgType = 0

let PACKET_TX_MAX_PAYLOAD_LENGTH = 19
var beanP: [UInt8] = [] // Bean Packet to send

// these are temporary for debugging & logging
var beanMsgArray: [[UInt8]] = []
var beanSendMsgArray: [[UInt8]] = []
var gtHeaderArray: [[UInt8]] = []
var tmpBeanMsg: [UInt8] = []
var vw = 0

// -----------------------------


//Bean Message Types (subset for now)
enum MSG_ID_T: Int{
    case MSG_ID_CC_LED_WRITE          = 0x2000
    case MSG_ID_CC_LED_WRITE_ALL      = 0x2001
    case MSG_ID_CC_LED_READ_ALL       = 0x2002
    case MSG_ID_CC_ACCEL_READ         = 0x2010
    case MSG_ID_CC_TEMP_READ          = 0x2011
    case MSG_ID_CC_BATT_READ          = 0x2015
    case MSG_ID_CC_POWER_ARDUINO      = 0x2020
    case MSG_ID_CC_GET_AR_POWER       = 0x2021
}

//
public extension Data {
    var u8:UInt8 {
        assert(self.count >= 0)
        var byte:UInt8 = 0x00
        (self as NSData).getBytes(&byte, length: 1)
        return byte
    }
    
    var u16:UInt16 {
        assert(self.count >= 2)
        var word:UInt16 = 0x0000
        (self as NSData).getBytes(&word, length: 2)
        return word
    }
    
    var u32:UInt32 {
        assert(self.count >= 4)
        var u32:UInt32 = 0x00000000
        (self as NSData).getBytes(&u32, length: 4)
        return u32
    }
    
    var u8s:[UInt8] { // Array of UInt8, Swift byte array basically
        var buffer:[UInt8] = [UInt8](repeating: 0, count: self.count)
        (self as NSData).getBytes(&buffer, length: self.count)
        return buffer
    }
    
    var utf8:String? {
        return String(data: self, encoding: String.Encoding.utf8)
    }
}

// UUIDs
// I wanted to have access to Serial & all 5 Scratch characteristics
let BLEServiceUUID = CBUUID(string: "A495FF10-C5B1-4B44-B512-1370F02D74DE") // ID Bean Service
let SerialUUID = CBUUID(string: "A495FF11-C5B1-4B44-B512-1370F02D74DE") // Serial Transport
let BLEDataUUID = CBUUID(string: "A495FF20-C5B1-4B44-B512-1370F02D74DE") // ID Scratch Services
let Scratch1UUID = CBUUID(string: "A495FF21-C5B1-4B44-B512-1370F02D74DE") // ID Scratch 1
let Scratch2UUID = CBUUID(string: "A495FF22-C5B1-4B44-B512-1370F02D74DE") // ID Scratch 2
let Scratch3UUID = CBUUID(string: "A495FF23-C5B1-4B44-B512-1370F02D74DE") // ID Scratch 3
let Scratch4UUID = CBUUID(string: "A495FF24-C5B1-4B44-B512-1370F02D74DE") // ID Scratch 4
let Scratch5UUID = CBUUID(string: "A495FF25-C5B1-4B44-B512-1370F02D74DE") // ID Scratch 5


public class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    
    fileprivate var centralManager: CBCentralManager?
    fileprivate var peripheralBLE: CBPeripheral?
    
    // this is the main view controller, that will show the UIKit elements
    
    var sendButton : UIButton!
    var myTextField : UITextField!
    var term : UITextView!
    var status : UILabel!
    var scratch1 : UITextField!
    var scratch2 : UITextField!
    var scratch3 : UITextField!
    var scratch4 : UITextField!
    var scratch5 : UITextField!
    var ledButton : UIButton!
    
    override public func viewDidLoad() {
        // UI done manually through code. Would prefer to use a Storyboard but,
        // I haven't figured out how to do it yet.
        // Need to add layout constraints so that ui works in all orientations
        
        let view = UIView()
        view.backgroundColor = UIColor(red: 189/255, green: 186/255, blue: 170 / 255, alpha: 1.0)
        
        // serial terminal view
        term = UITextView(frame: CGRect(x: 20, y: 80, width: 650, height: 300))
        term.textColor = UIColor.darkGray
        term.allowsEditingTextAttributes = true
        term.backgroundColor = UIColor(red: 199/255, green: 248/255, blue: 193/255, alpha: 1.0) 
            // must have text in term in order to set font
        updateTerminal(text2Update: "Welcome to my Bean Terminal Playground !\n")
        term.textAlignment = NSTextAlignment.left
        term.font = term.font?.withSize(20) // Large font for Old eyes
        view.addSubview(term)
        
        myTextField = UITextField(frame: CGRect(x: 20, y: 400, width: 300, height: 40))
        myTextField.borderStyle = UITextBorderStyle.roundedRect
        myTextField.autocapitalizationType = .none
        myTextField.placeholder = "Type here."
        view.addSubview(myTextField)
        
        sendButton = UIButton(frame: CGRect(x: 340, y: 400, width: 50, height: 40))
        sendButton.setTitle("Send", for: UIControlState.normal)
        sendButton.setTitleColor(UIColor.blue, for: UIControlState.normal)
        sendButton.addTarget(self, action: #selector(sendText), for: UIControlEvents.touchUpInside)
        view.addSubview(sendButton)
        
        // UI Status
        status = UILabel(frame: CGRect(x: 20, y: 730, width: 650, height: 40))
        status.layer.borderWidth = 1
        status.layer.cornerRadius = 8
        status.layer.masksToBounds = true
        status.text = "Welcome to my Bean Terminal"
        status.textAlignment = .center
        status.font = status.font.withSize(20)
        view.addSubview(status)
        
        // Scratch 1
        let scratch1Label = UILabel(frame: CGRect(x: 20, y: 460, width: 80, height: 40))
        scratch1Label.text = "Scratch 1:"
        view.addSubview(scratch1Label)
        scratch1 = UITextField(frame: CGRect(x: 120, y: 460, width: 260, height: 40))
        scratch1.borderStyle = UITextBorderStyle.roundedRect
        scratch1.autocapitalizationType = .none
        view.addSubview(scratch1)
        
        // Scratch 2
        let scratch2Label = UILabel(frame: CGRect(x: 20, y: 510, width: 80, height: 40))
        scratch2Label.text = "Scratch 2:"
        view.addSubview(scratch2Label)
        scratch2 = UITextField(frame: CGRect(x: 120, y: 510, width: 260, height: 40))
        scratch2.borderStyle = UITextBorderStyle.roundedRect
        scratch2.autocapitalizationType = .none
        view.addSubview(scratch2)
        
        // Scratch 3
        let scratch3Label = UILabel(frame: CGRect(x: 20, y: 560, width: 80, height: 40))
        scratch3Label.text = "Scratch 3:"
        view.addSubview(scratch3Label)
        scratch3 = UITextField(frame: CGRect(x: 120, y: 560, width: 260, height: 40))
        scratch3.borderStyle = UITextBorderStyle.roundedRect
        scratch3.autocapitalizationType = .none
        view.addSubview(scratch3)
        
        // Scratch 4
        let scratch4Label = UILabel(frame: CGRect(x: 20, y: 610, width: 80, height: 40))
        scratch4Label.text = "Scratch 4:"
        view.addSubview(scratch4Label)
        scratch4 = UITextField(frame: CGRect(x: 120, y: 610, width: 260, height: 40))
        scratch4.borderStyle = UITextBorderStyle.roundedRect
        scratch4.autocapitalizationType = .none
        view.addSubview(scratch4)
        
        // Scratch 5
        let scratch5Label = UILabel(frame: CGRect(x: 20, y: 660, width: 80, height: 40))
        scratch5Label.text = "Scratch 5:"
        view.addSubview(scratch5Label)
        scratch5 = UITextField(frame: CGRect(x: 120, y: 660, width: 260, height: 40))
        scratch5.borderStyle = UITextBorderStyle.roundedRect
        scratch5.autocapitalizationType = .none
        view.addSubview(scratch5)
        
        // led Button
        ledButton = UIButton(frame: CGRect(x: 540, y: 400, width: 120, height: 40))
        ledButton.setTitle("Turn LED On", for: UIControlState.normal)
        ledButton.setTitleColor(UIColor.blue, for: UIControlState.normal)
        ledButton.setTitleColor(UIColor.green, for: UIControlState.selected)
        ledButton.addTarget(self, action: #selector(ledToggle), for: UIControlEvents.touchUpInside)
        view.addSubview(ledButton)
        
        
        self.view = view
        
        // Start the CoreBluetooth Communication Process 
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    @objc func sendText() {
        let whatYouTyped = myTextField.text
        // need to check for size limit <= 12 & !nil
        sendSerial(msgChars: whatYouTyped!)
        myTextField.text = nil
    }
    
    @objc func ledToggle() {
        if ledButton.currentTitle == "Turn LED On" {
            setLED(nRed: 255, nGreen: 255, nBlue: 255)
            ledButton.setTitle("Turn LED Off", for: UIControlState.normal)
            
        } else {
            setLED(nRed: 0, nGreen: 0, nBlue: 0)
            ledButton.setTitle("Turn LED On", for: UIControlState.normal)
        }
    }
    
    public func updateTerminal(text2Update: String) {
        term.text.append(text2Update)
    }
    
    override public var prefersStatusBarHidden: Bool {
        return true
    }
    
    //  Central Manager ()
    public func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch (central.state)
        {
        case .unsupported:
            // sendBTServiceNotification("BLE Not Supported")
            print("BLE Not Supported")
            break
        case .unauthorized:
            // sendBTServiceNotification("This Device is not authorized to use BLE")
            break
        case .unknown:
            // sendBTServiceNotification("unknown Central Manager error")
            break
        case .resetting:
            // sendBTServiceNotification("BLE Resetting")
            break
        case .poweredOff:
            // sendBTServiceNotification("BLE powered Off")
            break
        case .poweredOn:
            print("Scanning for Beans")
            startScanning()
        default:
            print(central.state.rawValue)
            break
            
        }
    }
    
    func startScanning() {
        //sendBTServiceNotification("Scanning for Bean...")
        print("Scanning for", BLEname)
        vcvw.status.text = "Scanning for \(BLEname)"
        if let central = centralManager {
            // NB-this will ONLY scan for Beans, looking for Bean BLEServiceUUID & BLEDataUUID
            central.scanForPeripherals(withServices: [BLEServiceUUID, BLEDataUUID], options: nil)
        }
    }
    
    //
    public func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData:[String : Any], rssi RSSI: NSNumber) {
        
        print(peripheral.description)
        print(peripheral.name)
        if (peripheral.name == BLEname) {
            // Check to see if found device matches the one we are looking for.
            print(peripheral.name!, "connect")
            // Connect to this device
            bean = peripheral
            // Be sure to retain the peripheral or it will fail during connection.
            // If not already connected to a peripheral, then connect to this one
            //
            if ((peripheralBLE == nil) || (peripheralBLE?.state == CBPeripheralState.disconnected)) {
                
                //
                peripheralBLE = peripheral
                //
                central.connect(peripheral, options: nil)
            }
        }
    }
    
    //
    public func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        peripheral.delegate = self
        peripheral.discoverServices([BLEServiceUUID, BLEDataUUID])
        //
        central.stopScan()
        //sendBTServiceNotification("Connected to \(peripheral.name!)")
        print("Connected to \(peripheral.name!)")
        vcvw.status.text = "Connected to \(peripheral.name!)"
    }
    
    //
    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        
        //
        if (peripheral == peripheralBLE) {
            peripheralBLE = nil;
        }
        startScanning()
    }
    
    
    //
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        let uuidsForBTService: [CBUUID] = [SerialUUID, Scratch1UUID, Scratch2UUID, Scratch3UUID, Scratch4UUID, Scratch5UUID]
        
        if (peripheral != peripheralBLE) {
            //
            return
        }
        if (error != nil) {
            return
        }
        if ((peripheral.services == nil) || (peripheral.services!.count == 0)) {
            //
            return
        }
        //
        for service in peripheral.services! {
            if service.uuid == BLEDataUUID || service.uuid == BLEServiceUUID {
                peripheral.discoverCharacteristics(uuidsForBTService, for: service )
            }
        }
    }
    
    //
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if (peripheral != peripheralBLE) {
            return
        }
        if (error != nil) {
            return
        }
        for characteristic in service.characteristics! {
            if characteristic.uuid == SerialUUID {
                beanSerialCharacteristic = characteristic
                peripheral.setNotifyValue(true, for: characteristic )
                peripheral.readValue(for: characteristic )
                //print("setNotify for Serial Transport")
                // Get the LED Status to update future led button
                requestLEDColors()
                sendSerial(msgChars: "")
            }
            else if characteristic.uuid == Scratch1UUID {
                peripheral.setNotifyValue(true, for: characteristic )
                peripheral.readValue(for: characteristic )
                //print("setNotify for Scratch 1:")
            }
            else if characteristic.uuid == Scratch2UUID {
                peripheral.setNotifyValue(true, for: characteristic )
                peripheral.readValue(for: characteristic)
                //print("setNotify for Scratch 2:")
            }
            else if characteristic.uuid == Scratch3UUID {
                peripheral.setNotifyValue(true, for: characteristic )
                peripheral.readValue(for: characteristic)
                //print("setNotify for Scratch 3:")
            }
            else if characteristic.uuid == Scratch4UUID {
                peripheral.setNotifyValue(true, for: characteristic )
                peripheral.readValue(for: characteristic)
                //print("setNotify for Scratch 4:")
            }
            else if characteristic.uuid == Scratch5UUID {
                peripheral.setNotifyValue(true, for: characteristic )
                peripheral.readValue(for: characteristic)
                //print("setNotify for Scratch 5:")
            }
        }
    }
    
    //
    public func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        if characteristic.uuid == SerialUUID {
            let serialDataBytes = characteristic.value
            let bM = serialDataBytes?.u8s
            processBeanTransportMessage(beanMsg: bM!)
            //processBeanTransportMessage(beanMsg: (serialDataBytes?.u8s)!)
        }
        
        else if characteristic.uuid == Scratch1UUID {
            let scratchDataBytes = characteristic.value
            print(scratchDataBytes?.endIndex)
            if scratchDataBytes?.endIndex != 0 {
                print(scratchDataBytes?.u8s)
                processBeanScratch1(beanMsg: (scratchDataBytes?.u8s)!)
            }
            
        }
        
        else if characteristic.uuid == Scratch2UUID {
            let scratchDataBytes = characteristic.value
            //processBeanScratch2(beanMsg: (scratchDataBytes?.utf8)!)
        }
        
        else if characteristic.uuid == Scratch3UUID {
            let scratchDataBytes = characteristic.value
            //processBeanScratch3(beanMsg: (scratchDataBytes?.utf8)!)
        }
        
        else if characteristic.uuid == Scratch4UUID {
            let scratchDataBytes = characteristic.value
            //processBeanScratch4(beanMsg: (scratchDataBytes?.utf8)!)
        }
        
        else if characteristic.uuid == Scratch5UUID {
            let scratchDataBytes = characteristic.value
            //processBeanScratch5(beanMsg: (scratchDataBytes?.utf8)!)
        }
    }
    
    public func disconnect() {
        // This isnt working rght now, but need it to work in the future
        //if let peripheralBLE = peripheralBLE.availablePeripheral {
        //central.cancelPeripheralConnection(peripheralBLE!)
        //}
        print("Disconnecting from", BLEname)
    }
    
    // processBeanTransportMessage()
    // Assemble Bean Message packets into one complete data package to process.
    public func processBeanTransportMessage(beanMsg: [UInt8]) {
        // Parse transport message info
        let nGTHeader = beanMsg[0]
        let nGTStart = ((nGTHeader >> 7) & 1)
        let nGTMsgNum = Int((nGTHeader >> 5) & 3)
        let nGTMsgLeft = Int(nGTHeader & 31)
        gtHeaderArray.append([UInt8(nGTStart), UInt8(nGTMsgNum), UInt8(nGTMsgLeft)])
        //print("GT Header: \(nGTHeader)  Start: \(nGTStart)   Msg #: \(nGTMsgNum)   Msgs Left: \(nGTMsgLeft)   Current Msg #: \(currentGTMsgNum)  Bean Packet:\(beanMsg)")
        
        if nGTStart == 1 { // && currentGTMsgNum != nGTMsgNum {
            // Start New Bean Serial Message
            currentGTMsgNum = nGTMsgNum
            tmpBeanMsg = beanMsg
            if nGTMsgLeft == 0 {
                // Bean Message Complete so we can process it now
                // debug  beanMsgArray.append(tmpBeanMsg)
                processBeanMessage(beanMsg: tmpBeanMsg)
            }
        } else {
            if currentGTMsgNum == nGTMsgNum {
                // still working on the same message
                for i in beanMsg.startIndex + 1 ... beanMsg.endIndex - 1 {
                    tmpBeanMsg.append(beanMsg[i])
                }
                if nGTMsgLeft == 0 {
                    // Bean Message Complete so we can process it now
                    // debug  beanMsgArray.append(tmpBeanMsg)
                    processBeanMessage(beanMsg: tmpBeanMsg)
                }
            }
        } 
    }
    
    
}



// =============================================
/*
 * Represents a LightBlue Serial Transport Message
 *
 * Defined as:
 *
 *    [1 byte]         - Length     (Message ID + Payload)
 *    [1 byte]         - Reserved
 *    [2 byte]      BE - Message ID
 *    [0-64 bytes]  LE - Payload
 *    [2 bytes]     LE - CRC        (Everything before CRC)
 *
 Process the received Bean Message & act on it based on message type
 */

public func processBeanMessage(beanMsg: [UInt8]) {
    let nMsgLength = beanMsg[1] - 2
    let nMsgType = (Int(beanMsg[3]) << 8) + Int(beanMsg[4])
    let nCRC = (Int(beanMsg[beanMsg.endIndex - 1])  << 8) + Int(beanMsg[beanMsg.endIndex-2])
    // Drop serial packet & message overhead & checksum
    if beanMsg.endIndex >= 7 {
        var arrMsg: [UInt8] = []
        //remove header byte & 2 crc bytes at the end for crc16 calculation
        for i in beanMsg.startIndex + 1 ... beanMsg.endIndex - 3 {
            arrMsg.append(beanMsg[i])
        }
        let calcCrc16 = crc16(byteSequence: (arrMsg))
        arrMsg = [] // reset to just get the message
        for i in beanMsg.startIndex + 5 ... beanMsg.endIndex - 3 {
            arrMsg.append(beanMsg[i])
        }
        //print("Message length: \(nMsgLength) \nMessage type: \(nMsgType)  \nCRC: \(nCRC) \ncrc16: \(calcCrc16)")
        //print(beanMsg)
        switch nMsgType {
        case 0x0000:  // Serial Transport Message
            print(arrMsg) 
            let str = String(bytes: arrMsg, encoding: String.Encoding.utf8)
            if ((str?.endIndex) != nil) {
                //serialmsgs += str!
                vcvw.term.text.append(str!)
                //vcvw.updateTerminal(text2Update: str!)
            }
        case 0x2082: // 32 130 Get RGB LED
            print("RGB LED: \(arrMsg)")
            vcvw.term.text.append("#### RGB LED: \(arrMsg)")
        case 0x2090: // 32 144 Accelerometer readings
            print("Accelerometer readings: x,y,z \(arrMsg)")
            processAccelerometer(arrAccel: arrMsg)
        case 0x2091: // 32 145 Temperature reading
            beanTemp = Int(arrMsg[0]) // Double(arrMsg) * 1.8 + 32
        //print("Temperature: \(beanTemp)℃  \(Double(beanTemp) * 1.8 + 32)℉")
        case 0x2080: // 32 149 (actually 32 128) Bean Voltage 
            beanBattLevel = Int(arrMsg[0])
        //print("Voltage response: \(Int(arrMsg[0]))%", arrMsg)
        case 0x20A1: // 32 161 Bean Arduino power state
            if arrMsg[0] == 0 {
                beanArduinoPower = false
            } else {
                beanArduinoPower = true
            }
        //print("Bean Arduino Power: ", arrMsg) // 1=On 0=Off
        case 0x4000: // 64 00 Bean Error
            print("Bean Error: \(arrMsg)")
        default:
            print("Message type: \(nMsgType) \n \(arrMsg)")
        }
    }
    
}



// This function will be in BeanTransport.swift
public func processBeanScratch1(beanMsg: [UInt8]) {
    let scratch = String(bytes: beanMsg, encoding: String.Encoding.utf8)
    //print(beanMsg, scratch1)
    if ((scratch?.endIndex) != nil) {
        vcvw.scratch1.text = scratch!
    }
}

// This function will be in BeanTransport.swift
func processBeanScratch2(beanMsg: [UInt8]) {
    let scratch = beanMsg
}

// This function will be in BeanTransport.swift
func processBeanScratch3(beanMsg: [UInt8]) {
    let scratch = beanMsg
}

// This function will be in BeanTransport.swift
func processBeanScratch4(beanMsg: [UInt8]) {
    let scratch = beanMsg
}

// This function will be in BeanTransport.swift
func processBeanScratch5(beanMsg: [UInt8]) {
    let scratch = beanMsg
}

func sendBeanTransportPacket(beanMsg: [UInt8]) {
    // will need to enhance to be able to send messages 
    // that span more than 1 btpacket
    if beanMsg.endIndex > PACKET_TX_MAX_PAYLOAD_LENGTH {
        print("ERROR: Packet too long.")
        return 
    }
    let nCRC = crc16(byteSequence: beanMsg)
    var beanPacket: [UInt8] = []
    beanPacket.append(0x80 + (UInt8(sGTMsgNum) << 5))
    beanPacket = beanPacket + beanMsg
    beanPacket.append(UInt8(nCRC & 0xff))
    beanPacket.append(UInt8((nCRC >> 8) & 0xff))
    print("Sending: \(beanPacket)")
    beanSendMsgArray.append(beanPacket)
    let beanDataToSend = Data(beanPacket)
    bean?.writeValue(beanDataToSend as Data, for: beanSerialCharacteristic!, type: CBCharacteristicWriteType.withoutResponse)
    sGTMsgNum += 1
    if sGTMsgNum > 3 {
        sGTMsgNum = 0
    }
    // TODO: add multiple messages so that you can send more than 12 characters + 0x0d chr(13)
}

func sendSerial(msgChars: String) {
    let array: [UInt8] = Array(msgChars.utf8)
    //let serialMsg = [UInt8(array.endIndex + 3), 0x00, 0x00, 0x00] + array + [0x0d] // + 3
    let serialMsg = [UInt8(array.endIndex + 2), 0x00, 0x00, 0x00] + array
    print(msgChars, serialMsg)
    sendBeanTransportPacket(beanMsg: serialMsg)
}

func sendMessageWithID(identifier: Int, payload: [UInt8]) {
    let id: [UInt8] = [UInt8((identifier >> 8) & 0xff),UInt8((identifier & 0xff))]
    let msg = [ UInt8(id.count + payload.count + 2), 0x00] + id + payload
    print("Message ID: \(id) Payload: \(payload)  Message to Send: \(msg)")
    sendBeanTransportPacket(beanMsg: msg)
    sendSerial(msgChars: "") // do i need to send extra message to get bean to respond???? This seems to work.
}

func processAccelerometer(arrAccel: [UInt8]) {
    //print(arrAccel)
    var nTmp: UInt32 = 0
    nTmp = UInt32((UInt16(arrAccel[2]) << 8) + UInt16(arrAccel[1]))
    if (nTmp & 0x8000) == 0x8000 {
        //nTmp = -1 * ((0x10000 - nTmp) & 0x0000FFFF)
    }
    var lastX = Double(nTmp) * 3.91E-3
    nTmp = UInt32((UInt16(arrAccel[4]) << 8) + UInt16(arrAccel[3]))
    if (nTmp & 0x8000) == 0x8000 {
        //nTmp = -1 * ((0x10000 - nTmp) & 0x0000FFFF)
    }
    var lastY = Double(nTmp) * 3.91E-3
    nTmp = UInt32((UInt16(arrAccel[6]) << 8) + UInt16(arrAccel[5]))
    if (nTmp & 0x8000) == 0x8000 {
        //nTmp = -1 * ((0x10000 - nTmp) & 0x0000FFFF)
    }
    var lastZ = Double(nTmp) * 3.91E-3
}


public func setLED(nRed: UInt8, nGreen: UInt8, nBlue: UInt8) {
    let data: [UInt8] = [ nRed, nGreen, nBlue ]
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_LED_WRITE_ALL.rawValue, payload: data)
}

public func setArduinoPower(nPower: UInt8) {
    print("Set Arduino power state.")
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_POWER_ARDUINO.rawValue, payload: [nPower])
}

func requestTemperature() {
    //print("Request Bean Temperature.")
    beanP = []
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_TEMP_READ.rawValue, payload: beanP)
}
func requestVolts() {
    //print("Request Bean Voltage.")
    beanP = []
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_BATT_READ.rawValue, payload: beanP)
}
func requestAccel() {
    //print("Request Acceleroeter Readings.")
    beanP = []
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_ACCEL_READ.rawValue, payload: beanP)
}
func requestBeanArduinoPowerStatus() {
    //print("Request Bean Arduino Power Status.")
    beanP = []
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_GET_AR_POWER.rawValue, payload: beanP)
}
func requestLEDColors() {
    //print("Request LED Colors.")
    beanP = []
    sendMessageWithID(identifier: MSG_ID_T.MSG_ID_CC_LED_READ_ALL.rawValue, payload: beanP)
}

func crc16(byteSequence: [UInt8]) -> UInt16 {
    var crc: UInt16 = 0xffff
    for b in byteSequence {
        crc = (crc >> 8) | (crc << 8)
        crc ^= UInt16(b)
        crc ^= (crc & 0xff) >> 4
        crc ^= (crc << 8) << 4
        crc ^= ((crc & 0xff) << 4) << 1
    } 
    return crc
}

// ################################################

let vcvw = ViewController()


let mgr = CBCentralManager(delegate: vcvw, queue: nil)

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = vcvw



